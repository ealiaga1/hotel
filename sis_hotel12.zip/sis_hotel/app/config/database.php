<?php
// hotel_completo/app/config/database.php

// Define las constantes de conexión a la base de datos
define('DB_HOST', 'localhost'); // O la IP de tu servidor de base de datos
define('DB_NAME', 'u210964406_hotel2025'); // El nombre de tu base de datos
define('DB_USER', 'u210964406_uhotel2025'); // Tu nombre de usuario de la base de datos
define('DB_PASS', '1324MMa1240$');   // Tu contraseña de la base de datos
define('DB_CHARSET', 'utf8mb4'); // Conjunto de caracteres recomendado