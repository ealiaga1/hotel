<?php
// hotel_completo/test_db.php

require_once __DIR__ . '/app/lib/Database.php';

try {
    // Obtener la instancia de la conexión a la base de datos
    $db = Database::getInstance();
    $pdo = $db->getConnection();

    echo "<h3>¡Conexión a la base de datos exitosa!</h3>";
    echo "<p>Intentando recuperar algunos roles:</p>";

    // Ejemplo de consulta para verificar que todo funciona
    $stmt = $pdo->query("SELECT id_rol, nombre_rol FROM roles LIMIT 5");
    $roles = $stmt->fetchAll();

    if (!empty($roles)) {
        echo "<table border='1'>";
        echo "<tr><th>ID Rol</th><th>Nombre Rol</th></tr>";
        foreach ($roles as $rol) {
            echo "<tr><td>" . htmlspecialchars($rol['id_rol']) . "</td><td>" . htmlspecialchars($rol['nombre_rol']) . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No se encontraron roles en la base de datos.</p>";
    }

} catch (Exception $e) {
    echo "<h3>Error al conectar o consultar la base de datos:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}