// Código JavaScript personalizado del hotel
// Este archivo debe existir y ser accesible