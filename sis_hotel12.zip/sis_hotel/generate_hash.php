<?php

// Contraseña que quieres hashear
$password_to_hash = '1324MMa1240$'; // <--- ¡CAMBIA ESTO!

// Genera el hash
$hashed_password = password_hash($password_to_hash, PASSWORD_DEFAULT);

echo "Contraseña original: " . $password_to_hash . "<br>";
echo "Hash generado: " . $hashed_password . "<br><br>";
echo "Copia el 'Hash generado' y pégalo en tu sentencia INSERT o UPDATE para la tabla 'usuarios'.";

?>